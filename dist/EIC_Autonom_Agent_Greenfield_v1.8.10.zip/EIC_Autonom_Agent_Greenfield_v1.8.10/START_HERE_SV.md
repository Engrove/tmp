# Greenfield 1.8.10 – börja här

Greenfield 1.8.10 känner igen meddelandena i ChatGPT:s nya gränssnitt. Den ser alltså att en skickad prompt har kommit fram och läser svaret, i stället för att stanna i SENDING med ”Oklart om prompten skickades – inget omskick”. Se [UPPDATERA_TILL_1_8_10.md](UPPDATERA_TILL_1_8_10.md).

Sedan 1.8.9 startar Greenfield arbetskön även när ingen EIC-adress finns sparad, till exempel efter en ny installation. Välj EIC under **Fästa** på ChatGPT:s startsida och tryck **Starta arbetskö**. Greenfield hittar EIC:s adress via sidofältets **Senaste**, sparar den och startar i en ny EIC-chatt. Startfel visas direkt under köknapparna. ”Pro” i modellväljaren godkänns som högsta tänknivå. Se [UPPDATERA_TILL_1_8_9.md](UPPDATERA_TILL_1_8_9.md).

Version 1.8.8 rättar fyra kvarvarande felgrupper: verifierad generering får en tidsbegränsad respit från återhämtning, sena återhämtningssteg separeras med minst 60 sekunder, en annan aktiv GPT får inte byta köns bundna mål, och en omdirigering till GPT-roten raderar inte en pågående konversations återställningsadress. Respiten är högst fyra timmar från promptens utskick och kräver positiv stopp-/strömningssignal. Modellkrav, kvalitetskarantän och runtimeControl-kontrakt är oförändrade. Se [UPPDATERA_TILL_1_8_8.md](UPPDATERA_TILL_1_8_8.md) och [funktionell patchanalys](docs/RISKANALYS_FUNKTION_V1_8_8.md). **Live Chrome är inte verifierat i denna leverans.**

Greenfield 1.8.7 anpassar köstarten till ChatGPT:s nya gränssnitt. Kön öppnar aldrig standardchatten. Den går till den verifierade EIC-GPT:n, väljer vid behov EIC under **Fästa** och skickar först när sidan visar EIC. Håll därför EIC fäst i sidofältet. Se [UPPDATERA_TILL_1_8_7.md](UPPDATERA_TILL_1_8_7.md) och den funktionella riskanalysen [docs/RISKANALYS_FUNKTION_V1_8_7.md](docs/RISKANALYS_FUNKTION_V1_8_7.md).

Greenfield 1.8.6 rättar att kön kunde hänga efter att TTL gått ut, när ChatGPT:s modellval inte kunde verifieras. Tidsstegen (Ctrl-F5 60/90, köbyte vid 120 min) fortsätter nu under spärren, och ingen prompt skickas utan giltigt modellbevis. Tänknivån i ChatGPT:s nya modellväljare (”Extra hög”, ”Hög”) godkänns. Står väljaren på ”Direkt” väntar Greenfield tills du väljer en tänknivå. Se [UPPDATERA_TILL_1_8_6.md](UPPDATERA_TILL_1_8_6.md).

Greenfield 1.8.5 samlar administrationen av sparade uppdrag under **Uppdragskö → Sparade uppdrag**: redigera, spara ändring med samma id, spara som nytt, ta bort med bekräftelse, importera många texter med förhandsgranskning, exportera och städa. GF-ID:t på första raden är uppdragets identitet. Köplatser och kö-set hämtar alltid den aktuella texten. Taket är 64 och inget raderas automatiskt. ChatGPT:s notis ”Våra system bearbetar den här förfrågan …” fångas aldrig som svar.

Greenfield 1.8.4 rättar fältet Modellgolv under Körkrav. Chrome loggar inte längre felet ”Pattern attribute value GPT[- ]… is not a valid regular expression”, och panelen stoppar nu ett ogiltigt modellnamn redan i fältet.

Greenfield 1.8.3 återhämtar själv en vit ruta, ett halvladdat ChatGPT-gränssnitt eller en flik som inte svarar: omladdning, hård omladdning, samma URL, och till sist en ny flik med samma konversation. Visar ChatGPT ett Daybreak-spärrkort fortsätter samma GFW i en ny chatt. Vid upprepning inom 24 h pausas GFW:n (2/6/24 h) och kön går vidare. Den blir aldrig blockerad.

Greenfield 1.8.2 fångar inte längre halvfärdiga svar: ett JSON-svar som inte är färdigskrivet väntas ut. Om ett svar ändå inte tas emot visar **Exportera diagnostik** varför, under `responseObservation`, även när Audit är avslaget.

Greenfield 1.8.1 ger varje köplats kör- och paustider: veckofönster i lokal tid och en paus till en tidpunkt. Platsen körs bara inom sitt schema. En pågående tur avbryts aldrig, och när fönstret stänger går kön vidare efter svaret. Ett sparat kö-set kan skrivas över med aktiv kö.

Greenfield 1.8.0 lägger till **EIC Learning & Continuity Control** i prompten. FULL-prompten bär ett fristående kontrakt för AIK, Self-learn, Kaizen och Operator Learning. Varje prompt bär kapseln `control.learningControl` där Greenfield anger vilka kontroller som är obligatoriska just nu. AI:n rapporterar utfallet i svarsfältet `learningControl`. Greenfield hämtar eller skriver inget i lärande-lagren själv.

Greenfield 1.7.7 verkställer EIC-AI:ns terminala signal (`DONE`/`STOP_PROCESS`/`COMPLETE_MISSION`) som pensionering av hela den logiska GFW:n. AI:n får också begära validerad kvant- och prioritetsändring för aktuell köplats. Operatören har alltid företräde. Följdprompter i samma konversation kan vara COMPACT; FULL skickas vid varje sessionsgräns och var tionde prompt. Sedan 1.7.8 är en omladdning av samma konversation ingen sessionsgräns, varken Greenfields egen F5/Ctrl-F5 eller en manuell F5. Sedan 1.7.9 ger 120 min utan färdigt svar ett köbyte till nästa körbara GFW, och overlayen i fliken visar en snabböversikt med nedräkning.

Från tidigare versioner bevaras den deterministiska Uppdragskön, 1.7.5:s autonoma lagringsretention och 1.7.6:s fresh project owner-state / `current_focus` reconciliation som explicit A2A-invariant. `current_focus` är en restart/steering pointer, inte factual owner; nyare exakt owner-evidence vinner, stale focus får inte replaya completed effects och focus skrivs bara efter material steering/restart delta.



## Schemalagd kö i 1.8.1

- Klicka **Schema** på en plats i Aktiv kö. Lägg till körfönster (dagar + start–slut, lokal tid) och eventuell **Pausa till**. Spara.
- Utan fönster körs platsen alltid. Slut före start betyder över midnatt.
- Stänger fönstret under en tur blir turen klar, platsen parkeras med sin kvant och nästa plats startar. Finns ingen körbar plats visar panelen ”Kön väntar” med nästa start.
- EIC-AI:n kan ändra aktuell plats schema (`SET_SCHEDULE`). Din senare ändring vinner alltid.
- **Uppdatera valt** under Sparade kö-set skriver över valt set med aktiv kö. Klicka två gånger för att bekräfta.

## Lärande- och kontinuitetskontroll i 1.8.0

- Kontraktet (`responseContract.learningControlContract`) skickas i varje FULL-prompt. COMPACT bär bara en påminnelse om att det gäller.
- Kapseln (`control.learningControl`) skickas i varje prompt. Den anger `project.aikScope`, arbetsblock, keypoints med trigger och obligation per kontroll.
- `REQUIRED` får inte hoppas över tyst. En REQUIRED-kontroll som saknas i svaret står i nästa prompts `carriedOverObligations`.
- Ett rapporterat AIK discovery-resultat kan återanvändas inom samma arbetsblock (`FRESH_RESULT_REUSABLE`). Ny session eller köaktivering kräver ny discovery.
- Factual owner vinner alltid över AIK, Memory och lessons.

## AI runtime-control i 1.7.7

- AI:n begär; Greenfield äger effekten och validerar target, gränser och operatörsföreträde.
- `COMPLETE_MISSION` (eller `DONE`/`STOP_PROCESS`) pensionerar alla köplatser med samma `savedMissionId`.
- `SET_QUANTUM` 1..15 gäller från platsens nästa kvant; `SET_PRIORITY` kan inte gå över operatörens prioritet.
- Kvitton visas i nästa prompt under `control.runtimeControl.lastReceipts`.

## Owner-state/current_focus (från 1.7.6)

- Före första bounded work package ska färsk subject-project owner-state läsas.
- Project-bound arbete ska läsa och reconcile `project.current_focus`.
- `current_focus` behandlas som `STEERING_POINTER_NOT_FACT_OWNER`.
- Nyare exakt owner-evidence styr vid konflikt.
- Focus skrivs bara efter material steering/restart delta och write kräver owner readback.
- Om metadata-write är unavailable ska restart pointer bevaras via annan korrekt durable owner/chronology-route, felet routas till sin owner och unrelated safe work fortsätta utan blind retry.
- Completed objectives/effects får inte replayas på grund av stale focus.
- Exakt effect target/owner revalideras före material effect.
- Före pause/yield/block/done/handoff persisteras material mission state; focus ändras bara vid material restart delta.

## Autonom lagring från 1.7.5

- Vid 80 % av den nominella lokala lagringsgränsen startar automatisk retention.
- Målet är 70 % efter städning.
- Äldre checksummade checkpointslotar kompakteras först.
- Om mer utrymme behövs raderas de äldsta workerpaketen som **inte** är live-bundna i `chrome.storage.session`.
- Live-bundna workers raderas inte av retentionen.
- 90 % är inte längre en dispatchspärr.
- `unlimitedStorage` finns som kvotbuffert så att Greenfield kan städa även en redan full profil.

## Köprincipen från 1.7.4

1. `order` är den styrande ordningen inne i en Greenfield-worker; prioritet får inte hoppa över köplatser.
2. Efter sista körbara köplatsen wrappar kön till första körbara plats och fortsätter så länge kön är aktiverad.
3. `maxInteractions` är per köplats. En full kvant nollställer just den platsens kvantmätare inför nästa varv.
4. Tidig `YIELD_TO_QUEUE`, queue-local `PAUSE_PROCESS`/`BACKGROUND_SLEEP` eller temporär BLOCKED bevarar ofärdig kvantprogress i den platsen.
5. Samma `savedMissionId` kan finnas i flera slots. Varje slot har eget `itemId`, `order`, `priority`, `maxInteractions` och kvantprogress, men de delar senaste logiska mission-checkpoint/resume.
6. `PAUSE_PROCESS`/`BACKGROUND_SLEEP` pausar alla duplicate slots för samma sparade GFW och låter nästa annan runnable slot gå vidare; om ingen annan finns används vanlig processpause.
7. `DONE` eller `STOP_PROCESS` avslutar den logiska sparade GFW:n och tar bort alla dess duplicate slots, så den inte startas om av ett senare varv.
8. Slot-prioritet används av den profilglobala kapacitetsschedulern när slotten är aktiv; den påverkar inte inner-queue order.
9. Varje genererad queue-prompt visar kvantläget (`Hög · 1 interaktioner/kvant · 0/1 slutförda i kvanten`) och ett planningHint så EIC kan dimensionera just den promptens arbetspaket.
10. Greenfield anger ungefärlig response-roundtrip och efter återkomst ungefärlig loop-roundtrip för samma köplats.
11. EIC kan begära `greenfieldStatusRequest=FULL_NEXT_PROMPT`; nästa prompt för samma GFW innehåller ett bounded full process-statusobjekt utöver standardinformationen.
12. `CONTINUE + BACKGROUND_SLEEP` är alltid park/schedule, aldrig Klart/avslutad. Endast `DONE`/`STOP_PROCESS` avslutar den logiska GFW:n.

## Bevarad språk- och evidenceprincip

1. Greenfields interna A2A-, Nano- och Hjalmar-kontrollspråk är engelska.
2. Browser/UI/operator/source-evidence får samtidigt vara en kontinuerlig blandning av engelska, svenska och finska.
3. Råa labels bevaras på originalspråk.
4. Strukturell control-identitet och lokal språk-/fraskontext kommer före lexikal effort-ranking.
5. En mixed-language parsing-ambiguitet är inte i sig bevis på att modellen eller tänknivån faktiskt har ändrats.
6. Heavy/Max-krav fortsätter fail-closed när verklig effort inte kan etableras.

## Modellkontrollen

- Den breda globala `button[aria-label*='Djup' i]`-matchningen är borttagen.
- Composer-lokala effort-kontroller prioriteras när de finns.
- Svenska `nåla fast`/`fäst fast` skyddas från engelsk Fast-tolkning.
- Bounded finska termer för modell-/reasoning-UI stöds.
- Diagnostiken anger `effortEvidenceSource` så att en operator kan se om beviset kom från `COMPOSER_SELECTED_CONTROL` eller en svagare strukturell fallback.

## Installation över 1.8.8

1. Pausa nya Greenfield-utskick.
2. Säkerhetskopiera den uppackade tilläggsmappen.
3. Packa upp `EIC_Autonom_Agent_Greenfield_v1.8.10.zip`.
4. Kopiera innehållet över samma mapp som Chrome redan använder så extension-ID/lokal state bevaras.
5. I `chrome://extensions`, välj **Läs in igen**.
6. Verifiera att panelen visar `v1.8.10`. Följ sedan [UPPDATERA_TILL_1_8_10.md](UPPDATERA_TILL_1_8_10.md). Kommer du från 1.8.8, följ även [UPPDATERA_TILL_1_8_9.md](UPPDATERA_TILL_1_8_9.md), och från 1.8.7 även [UPPDATERA_TILL_1_8_8.md](UPPDATERA_TILL_1_8_8.md).
7. Återgå till den exakta EIC-konversation som hör till workern.
8. Kör **Kontrollera modell igen** och exportera diagnostik om safety-hold kvarstår.
9. Låt Greenfield reconcilea befintlig process-state; gör inget manuellt omskick av en dispatch med okänd effekt.

## Riktad liveacceptans

- Vid vit ruta eller en sida som inte svarar: panelen visar ”Flikåterhämtning: …” och stegen genomförs utan att du behöver klistra in URL:en.
- Vid ett Daybreak-kort: samma GFW fortsätter i en ny chatt. Vid upprepning syns pausen under platsens Schema.
- Kör långa djupgående turer. Verifiera i en diagnostikexport att nya turer inte har `responseChars` på några få tecken och att `responseObservation` innehåller spår.
- Om ett färdigt svar på skärmen inte tas emot: exportera diagnostik innan 120 minuter har gått och skicka filen.
- Sätt ett körfönster som stänger om några minuter på aktiv plats. Verifiera att pågående tur blir klar, att platsen parkeras (`SCHEDULE_WINDOW_CLOSED`) och att nästa plats startar, eller att kön väntar med nedräkning i overlayen.
- Verifiera att FULL-prompten innehåller `control.workQueue.scheduleRule` och att varje prompt har `control.workQueue.schedule`.
- Ändra aktiv kö och kör **Uppdatera valt** på ett kö-set. Verifiera samma namn och nytt antal uppdrag.
- Verifiera att första prompten innehåller `responseContract.learningControlContract` och `control.learningControl` med `AIK_DISCOVERY = REQUIRED` och rätt `project.aikScope`.
- Verifiera att en COMPACT-följdprompt innehåller `control.learningControl` men inte kontraktet.
- Verifiera att EIC-svaret innehåller `learningControl`. Om en REQUIRED-kontroll saknas ska nästa prompt lista den i `carriedOverObligations`.
- Kontrollera att overlayen i ChatGPT-fliken visar GFW-id, plats, prioritet, interaktion/kvant, en nedräknande TTL och nästa GFW i kön.
- Om en tur passerar 120 min utan färdigt svar: verifiera att nästa GFW i listordning startar i ny chatt och att den stallade köplatsen ligger kvar som redo med oförändrad kvantprogress.
- Lägg samma sparade GFW på två köplatser. Låt AI:n svara `DONE` + `STOP_PROCESS` och verifiera att båda platserna hamnar i `Klart/avslutade` medan andra GFW:er ligger kvar.
- Verifiera att ett AI-svar med `runtimeControl` `SET_PRIORITY` ändrar bara aktuell plats och att nästa prompt visar kvittot `APPLIED`.
- Ändra prioritet i panelen medan AI:n arbetar och verifiera att ett äldre AI-svar får `OPERATOR_PRECEDENCE`.
- Låt en tur passera 30 min (Greenfields egen F5) eller tryck F5 mellan två turer. Verifiera att nästa prompt ändå har `promptProfile.profile = COMPACT` i samma konversation.
- Byt till en annan chatt eller låt Greenfield rotera, och verifiera att nästa prompt har `promptProfile.profile = FULL`.
- Spara gärna den aktiva kön som ett kö-set innan extension-reload. Om du kopierar 1.8.6 över samma unpacked Chrome-mapp bevaras normalt samma extension-ID/lokal state; ett helt nytt unpacked extension-ID ska inte antas ärva aktiv runtime-kö.
- Starta minst två olika GFW-slots med olika prioritet och verifiera att **listordningen**, inte prioriteten, avgör nästa slot.
- Sätt en slot till kvant 2 och verifiera `0/2 → 1/2 → byte`, därefter att samma slot vid nästa fulla varv börjar på `0/2`.
- Avbryt en större kvant tidigt via en kökontroll och verifiera att dess ofärdiga kvant fortsätter från tidigare tal när slotten kommer tillbaka.
- Lägg samma sparade GFW två gånger på olika platser med olika prioritet/kvant och verifiera att båda slots visas och körs i respektive position utan att missionen startas om från början.
- Med `Djupgående` valt ska en samtidig `Djupanalys`/pin-kontroll inte skapa `ambiguous=true`.
- Diagnostics bör visa `effortLabel="Djupgående"` och, när composer-kontrollen kan bindas, `effortEvidenceSource="COMPOSER_SELECTED_CONTROL"`.
- Kör minst en autonom continuation efter att fresh modelproof godkänts.
- Bekräfta att tidigare multi-turn-liveness fortfarande fungerar.

Lokal paketverifiering kan verifiera koden och regressionerna. Den ersätter inte live Chrome/ChatGPT-acceptans.
